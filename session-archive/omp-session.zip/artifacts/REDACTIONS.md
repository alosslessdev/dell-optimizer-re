# Sanitized session archive

Updated export of the live omp session for the Dell Inspiron 15 3535 battery work.

Redacted before publication:

- drive serial number
- battery serial number and battery part number
- NTFS/partition/root filesystem UUIDs
- NVMe EUI
- hostname
- expired GitHub device-login code

No credentials, service tag, or Windows product key are present. The HTML viewer was omitted because the archive was generated outside the host export runtime.
