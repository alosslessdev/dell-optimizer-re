# Session archive

Generated 2026-10-19T05:04:43.260Z from session `01a11f4e-2cdb-70de-98ce-63fc3c7e27b6`.

## Layout

| Path | Contents |
| --- | --- |
| `manifest.json` | Index of everything below (counts, sizes, subagent list) |
| `session.jsonl` | The main session transcript, verbatim |
| `agents.json` | Live per-agent state captured while the session ran (model, system prompt, tools) |
| `jobs.json` | Background jobs: `completed` (recovered from transcripts) + `live` (running/recent at archive time) |
| `artifacts/` | Every file under the session artifact directory, verbatim |
| `viewer.html` | Standalone HTML viewer (all subagent sessions embedded) |

`artifacts/` is the important part: it holds each subagent's own
`<AgentId>.jsonl` transcript (recursively nested), the session's
`*.bash.log` / `*.eval.log` / `*.read.log` files with the **full, untruncated**
tool and background-job output, and `*.jsonl.tombstone` kill markers.

## Background jobs

14 completed jobs recovered from the transcripts (main + every subagent); full list in `jobs.json`. Per-job output lives in the owning transcript and in `artifacts/*.log`.

## Subagents (0)

_No subagent sessions were recorded for this session._

## Totals

6 files, 3432505 bytes.

Omitted:
- artifacts/: excluded for publication — untruncated logs contain bulk decompiled-source dumps (190 MB)
- viewer.html: omitted — headless run, host HTML exporter unavailable
- agents.json live state: unavailable in headless run
- jobs.json live state: unavailable in headless run; completed jobs derived from transcripts


## Sanitization

This archive was sanitized for publication (secrets removed, home paths normalized, decompiled-source excerpts redacted, artifacts excluded). A final pre-publication pass redacted 34 remaining decompiled-source blocks. See `SANITIZATION.md`.


## Sanitization

Sanitized for publication; see `SANITIZATION.md`.
