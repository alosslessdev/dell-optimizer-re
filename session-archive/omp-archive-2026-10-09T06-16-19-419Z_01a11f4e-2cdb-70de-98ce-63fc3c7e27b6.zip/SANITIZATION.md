# Sanitization report

Generated at: 2026-10-23T20:16:50.858279+00:00 (three passes)

| Action | Count |
|---|---|
| Decompiled-source excerpts redacted | 48 |
| Secret-pattern substitutions | 0 |
| Strings with home paths normalized (`/home/<user>` -> `~`) | 1242 |
| Second-pass C# code-density redactions | 4 (10385 bytes) |
| Third-pass (final, pre-publication) decompiled-source blocks | 34 (70336 bytes) |

Policy: publishable session archive — no proprietary binaries/source files, no secrets, no absolute
home paths, no untruncated decompiled-source logs.

Included: main session transcript (tool outputs as recorded/truncated by the host), manifest,
derived completed-job metadata, README.

Not included: `artifacts/` (190 MB of untruncated logs with bulk decompiled-source dumps — excluded via
the plugin's `--no-artifacts` mode), `viewer.html` (headless run, no host exporter), live
`agents.json`/`jobs.json` state (not observable in a headless run; completed jobs derived from the
transcript).

Detectors: ILSpy `//IL_` markers; full decompiled-file signatures (`namespace Dell.` + `using System`);
C# declaration density with markdown exemption; GitHub/AWS/Slack/Google/OpenAI-style tokens; bearer
tokens; private-key blocks; `password|secret|token|api_key = ...` assignments; `/home/<user>` paths.
